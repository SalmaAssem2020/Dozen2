import { PlaywrightTestConfig } from '@playwright/test';
const Environment = require('./Data/Environment');

const config: PlaywrightTestConfig = {  
  globalSetup: require.resolve('./Setup/global-setup'),
  workers: process.env.CI ? 1 : 2,
use: {
    baseURL: Environment.CDURL,
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    navigationTimeout: 12000 * 1000
  },

  reporter: [
    ['line'], 
    ['experimental-allure-playwright']
  ],
};


export default config;